# 2525 Group Website Project
edit the README.md to put shared notes in this file

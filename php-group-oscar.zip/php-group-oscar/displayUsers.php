<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
    require_once('database.php');
    $users = select_all();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>displayUsers</title>
        <link href="main.css" rel="stylesheet" type="text/css"/>
    </head>
    <body class="wrapper">
        <a href="index.php">Back</a>
        <table>
        <tr>
            <th>User Id</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Username</th>
            <th>Email</th>
        </tr>
        <?php foreach ($users as $user) : ?>

        <tr>
            <td><?php echo $user['userId']; ?></td>
            <td><?php echo $user['firstName']; ?></td>
            <td><?php echo $user['lastName']; ?></td>
            <td><?php echo $user['userName']; ?></td>
            <td><?php echo $user['emailAddress']; ?></td>
        </tr>
            <?php endforeach; ?>
        
        </table>
    </body>
</html>

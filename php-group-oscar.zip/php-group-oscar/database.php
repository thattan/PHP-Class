<?php
    $dsn = 'mysql:host=localhost;dbname=php-group-oscar';
    $username = 'root';
    $password = '';

    try {
        $db= new PDO($dsn, $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo $e->getMessage();
        //Displays the exception and keeps on rolling, uncomment the exit if you want it to halt instead
        //exit();
    }
    
    function add_user($fName, $lName, $userName, $email)
    {
        global $db;
        
        $query = 'INSERT INTO users
                 (firstName, lastName, userName, emailAddress)
              VALUES
                 (:fName, :lName, :userName, :email)';
        $statement = $db->prepare($query);
        $statement->bindValue(':fName', $fName);
        $statement->bindValue(':lName', $lName);
        $statement->bindValue(':userName', $userName);
        $statement->bindValue(':email', $email);
        $statement->execute();
        $statement->closeCursor();
    }
    
    function select_unique_userName($userName)
    {
        global $db;
        
        $queryUser = 'SELECT * FROM users
                      WHERE userName = :userName';
        $statement1 = $db->prepare($queryUser);
        $statement1->bindValue(':userName', $userName);
        $statement1->execute();
        $user = $statement1->fetch();
        if ($user > 0)
        {
            $tempUserName = $user['userName'];
        } else {
            $tempUserName = '';
        }
        $statement1->closeCursor(); 
        return $tempUserName;
    }
    
    function select_unique_email($email)
    {
        global $db;
        
        $queryUser = 'SELECT * FROM users
                      WHERE emailAddress = :emailAddress';
        $statement1 = $db->prepare($queryUser);
        $statement1->bindValue(':emailAddress', $email);
        $statement1->execute();
        $user = $statement1->fetch();
        if ($user > 0)
        {
            $tempEmail = $user['emailAddress'];
        } else {
            $tempEmail = '';
        }    
        $statement1->closeCursor(); 
        return $tempEmail;
    }
    
    function select_all()
    {
        global $db;
 
      $query = 'SELECT * FROM users';
      $statement = $db->prepare($query);
      $statement->execute();
      $results =  $statement->fetchAll();
      $statement->closeCursor();
      return $results;
    }

?>

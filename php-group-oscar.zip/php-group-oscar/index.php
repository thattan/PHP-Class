<?php
require_once('database.php');

if (!isset($fName)) { $fName = ''; } 
if (!isset($lName)) { $lName = ''; } 
if (!isset($userName)) { $userName = ''; }
if (!isset($email)) { $email = ''; }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Registration</title>
    </head>
    <body class="wrapper">
        <link href="main.css" rel="stylesheet" type="text/css"/>
    <h1>Enter Information</h1>
        <form action="confirmation.php" method="post">
            <label>First Name:</label>
            <input type="text" name="fName"
                   value="<?php echo htmlspecialchars($fName); ?>">
            <?php if (!empty($errorMessageFName)) { ?>
            <p class="error"><?php echo htmlspecialchars($errorMessageFName); ?></p>
            <?php } ?>
            <br><br>
            
            <label>Last Name:</label>
            <input type="text" name="lName"
                   value="<?php echo htmlspecialchars($lName); ?>">
            <?php if (!empty($errorMessageLName)) { ?>
            <p class="error"><?php echo htmlspecialchars($errorMessageLName); ?></p>
            <?php } ?>
            <br><br>
            
            <label>Username:</label>
            <input type="text" name="userName"
                   value="<?php echo htmlspecialchars($userName); ?>">
            <?php if (!empty($errorMessageUserName)) { ?>
            <p class="error"><?php echo htmlspecialchars($errorMessageUserName); ?></p>
            <?php } ?>
            <br><br>
            
            <label>Email:</label>
            <input type="text" name="email"
                   value="<?php echo htmlspecialchars($email); ?>">
            <?php if (!empty($errorMessageEmail)) { ?>
            <p class="error"><?php echo htmlspecialchars($errorMessageEmail); ?></p>
            <?php } ?>
            <br><br>
            <label>&nbsp;</label>
            
            <input type="submit" value="Submit">
            
            <button><a href="displayUsers.php">All Users</a></button>
            

            
        </form>
    </body>
</html>
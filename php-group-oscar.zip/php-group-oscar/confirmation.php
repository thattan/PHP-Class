<?php

//Get user data
$fName = filter_input(INPUT_POST, 'fName');
$lName = filter_input(INPUT_POST, 'lName');
$userName = filter_input(INPUT_POST, 'userName');
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$errorMessageFName = '';
$errorMessageLName = '';
$errorMessageUserName = '';
$errorMessageEmail = '';
$errorBoolean = false;


//Validate user data
if($fName === ''){
    $errorMessageFName = 'You must enter your first name.';
}

if ($lName === ''){
    $errorMessageLName = 'You must enter your last name.';
}
if ($userName === ''){
    $errorMessageUserName = 'You must enter a username.';
}
if (empty($email)){
    $errorMessageEmail = 'You must enter a valid email';
}

if ($errorMessageUserName == '' && $errorMessageEmail == '')
{
    require_once('database.php');
    $tempEmail = select_unique_email($email);
    $tempUserName = select_unique_userName($userName);
    
    if ($tempEmail !== '')
    {
        $errorMessageEmail = 'Email already exists';
    } 
    
    if ($tempUserName !== '')
    {
        $errorMessageUserName = 'User Name already exists';
    } 
    
    if ($errorMessageUserName == '' && $errorMessageEmail == '')
    {
        $errorBoolean = TRUE;
    }

}


if($errorBoolean == FALSE){
    include('index.php');
    exit();
}

if($errorBoolean == TRUE) {
    require_once('database.php');
    add_user($fName, $lName, $userName, $email);   
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Confirmation</title>
        <link href="main.css" rel="stylesheet" type="text/css"/>
        
    </head>
    
    <body class="wrapper">
        <main>
            <form>
            <h1>Thank You!</h1>
            
            <label>First Name:</label>
            <span><?php echo $fName; ?></span>
            <br>
            <label>Last Name:</label>
            <span><?php echo $lName; ?></span>
            <br>
            <label>Username:</label>
            <span><?php echo $userName; ?></span>
            <br>
            <label>Email:</label>
            <span><?php echo $email; ?></span>
            </form>
            
            
        </main>
    </body>
    
</html>
